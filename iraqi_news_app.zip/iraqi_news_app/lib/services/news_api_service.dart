import 'dart:convert';
import 'dart:async';
import 'package:http/http.dart' as http;
import '../models/news_article.dart';

/// Thrown when the remote news API cannot be reached or returns bad data.
class NewsApiException implements Exception {
  final String message;
  NewsApiException(this.message);
  @override
  String toString() => 'NewsApiException: $message';
}

/// Fetches real Iraqi news articles from a FreeNewsApi-style REST endpoint.
///
/// IMPORTANT — VERIFY BEFORE SHIPPING:
/// The base URL below (`freenewsapi.ai`) was supplied as the data source but
/// could not be independently verified as a live, documented service at the
/// time this code was written. Before relying on this in production:
///   1. Confirm the domain resolves and returns JSON matching the shape
///      assumed in `NewsArticle.fromApiJson`.
///   2. If it does not exist or changes shape, swap in a verified provider
///      (e.g. GDELT, NewsAPI.ai/NewsData.io with a free key, or your own
///      scraper/Cloud Function) — this class is the ONLY place that needs
///      to change; everything else in the app depends on `NewsArticle`,
///      not on this specific API.
/// This service degrades gracefully (returns an empty list + surfaces an
/// error) rather than crashing the app if the endpoint is unreachable.
class NewsApiService {
  static const String _baseUrl = 'https://freenewsapi.ai/v1/search';
  static const Duration _timeout = Duration(seconds: 15);

  final http.Client _client;

  NewsApiService({http.Client? client}) : _client = client ?? http.Client();

  /// Fetches today's Iraq news, sorted by date, newest first.
  ///
  /// [fullText] requests complete article bodies when the API supports it.
  /// [size] caps how many articles are returned (API-side limit).
  Future<List<NewsArticle>> fetchIraqNewsToday({
    bool fullText = false,
    int size = 50,
  }) async {
    final uri = Uri.parse(_baseUrl).replace(queryParameters: {
      'country': 'IQ',
      'date': 'today',
      'sort': 'date',
      'size': size.toString(),
      if (fullText) 'full_text': 'true',
    });

    try {
      final response = await _client.get(uri).timeout(_timeout);

      if (response.statusCode != 200) {
        throw NewsApiException(
          'Unexpected status code ${response.statusCode} from news API.',
        );
      }

      final decoded = jsonDecode(response.body);

      // Be defensive about the response envelope shape: some APIs return a
      // bare array, others wrap results under "articles"/"results"/"data".
      final List<dynamic> rawList = decoded is List
          ? decoded
          : (decoded['articles'] ??
              decoded['results'] ??
              decoded['data'] ??
              const []) as List<dynamic>;

      final articles = <NewsArticle>[];
      for (final item in rawList) {
        if (item is! Map<String, dynamic>) continue;
        try {
          final article = NewsArticle.fromApiJson(item);
          // Skip entries missing the essentials — a title and a source
          // link are the minimum needed to be useful and de-duplicable.
          if (article.title.isEmpty || article.sourceUrl.isEmpty) continue;
          articles.add(article);
        } catch (_) {
          // Skip malformed individual entries rather than failing the
          // whole batch.
          continue;
        }
      }

      return articles;
    } on TimeoutException {
      throw NewsApiException('The news service timed out. Please try again.');
    } on http.ClientException catch (e) {
      throw NewsApiException('Network error while fetching news: ${e.message}');
    } on FormatException {
      throw NewsApiException('The news service returned an unreadable response.');
    } catch (e) {
      throw NewsApiException('Failed to fetch news: $e');
    }
  }

  void dispose() => _client.close();
}
