import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/news_article.dart';
import '../models/user_model.dart';

/// Central wrapper around Firebase Auth + Firestore access.
///
/// Keeping all Firebase calls in one place makes it easy to mock in tests
/// and keeps providers/screens free of Firebase-specific code.
class FirebaseService {
  final FirebaseAuth _auth;
  final FirebaseFirestore _firestore;

  FirebaseService({FirebaseAuth? auth, FirebaseFirestore? firestore})
      : _auth = auth ?? FirebaseAuth.instance,
        _firestore = firestore ?? FirebaseFirestore.instance;

  // ---------------------------------------------------------------------
  // Auth
  // ---------------------------------------------------------------------

  Stream<User?> get authStateChanges => _auth.authStateChanges();
  User? get currentUser => _auth.currentUser;

  Future<UserCredential> signIn(String email, String password) {
    return _auth.signInWithEmailAndPassword(email: email, password: password);
  }

  Future<UserCredential> signUp(
      String email, String password, String? displayName) async {
    final credential = await _auth.createUserWithEmailAndPassword(
      email: email,
      password: password,
    );
    if (displayName != null && displayName.isNotEmpty) {
      await credential.user?.updateDisplayName(displayName);
    }
    // Mirror the user into Firestore so we have a queryable `users` doc.
    final model = UserModel(
      uid: credential.user!.uid,
      email: email,
      displayName: displayName,
    );
    await _firestore
        .collection('users')
        .doc(model.uid)
        .set(model.toFirestore());
    return credential;
  }

  Future<void> signOut() => _auth.signOut();

  // ---------------------------------------------------------------------
  // Articles
  // ---------------------------------------------------------------------

  CollectionReference<Map<String, dynamic>> get _articles =>
      _firestore.collection('articles');

  /// Streams articles for a given category, newest first. Pass `null`
  /// category for "All".
  Stream<List<NewsArticle>> streamArticles({NewsCategory? category}) {
    Query<Map<String, dynamic>> query =
        _articles.orderBy('publishedAt', descending: true).limit(100);

    if (category != null && category != NewsCategory.all) {
      query = query.where('category', isEqualTo: category.name);
    }

    return query.snapshots().map(
          (snap) => snap.docs.map(NewsArticle.fromFirestore).toList(),
        );
  }

  /// Writes freshly-fetched articles into Firestore, skipping any whose
  /// `sourceUrl` already exists (dedup key). Returns how many were newly
  /// inserted.
  ///
  /// Firestore has no native "unique constraint", so dedup is done by
  /// querying for each `sourceUrl` before writing. For larger batches this
  /// is best run from a trusted environment (Cloud Function) rather than
  /// the client, both for reliability and to avoid every user's device
  /// hammering the read quota — see functions/index.js.
  Future<int> saveArticlesDeduped(List<NewsArticle> articles) async {
    var inserted = 0;

    for (final article in articles) {
      if (article.sourceUrl.isEmpty) continue;

      final existing = await _articles
          .where('sourceUrl', isEqualTo: article.sourceUrl)
          .limit(1)
          .get();

      if (existing.docs.isNotEmpty) continue; // duplicate — skip

      await _articles.add(article.toFirestore());
      inserted++;
    }

    return inserted;
  }

  // ---------------------------------------------------------------------
  // Saved / favorite articles
  // ---------------------------------------------------------------------

  Future<void> toggleSaved(String uid, String articleId, bool save) {
    final userDoc = _firestore.collection('users').doc(uid);
    return userDoc.update({
      'savedArticleIds': save
          ? FieldValue.arrayUnion([articleId])
          : FieldValue.arrayRemove([articleId]),
    });
  }

  Stream<UserModel> streamUser(String uid) {
    return _firestore
        .collection('users')
        .doc(uid)
        .snapshots()
        .map(UserModel.fromFirestore);
  }

  Future<List<NewsArticle>> getArticlesByIds(List<String> ids) async {
    if (ids.isEmpty) return [];
    // Firestore `whereIn` is capped at 30 items per query.
    final chunks = <List<String>>[];
    for (var i = 0; i < ids.length; i += 30) {
      chunks.add(ids.sublist(i, i + 30 > ids.length ? ids.length : i + 30));
    }
    final results = <NewsArticle>[];
    for (final chunk in chunks) {
      final snap = await _articles
          .where(FieldPath.documentId, whereIn: chunk)
          .get();
      results.addAll(snap.docs.map(NewsArticle.fromFirestore));
    }
    return results;
  }
}
