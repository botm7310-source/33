import 'dart:ui';
import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// A translucent, blurred "glass panel" — the base building block of the
/// aqua/water aesthetic. Wraps [child] in a backdrop blur + soft border +
/// optional glow, matching the glassmorphism spec.
class GlassContainer extends StatelessWidget {
  final Widget child;
  final double borderRadius;
  final EdgeInsetsGeometry padding;
  final EdgeInsetsGeometry? margin;
  final bool glow;
  final double blurSigma;

  const GlassContainer({
    super.key,
    required this.child,
    this.borderRadius = AppRadii.card,
    this.padding = const EdgeInsets.all(16),
    this.margin,
    this.glow = false,
    this.blurSigma = 16,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: margin,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(borderRadius),
        boxShadow: glow ? AppColors.glow() : null,
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(borderRadius),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: blurSigma, sigmaY: blurSigma),
          child: Container(
            padding: padding,
            decoration: BoxDecoration(
              color: AppColors.glassFill,
              borderRadius: BorderRadius.circular(borderRadius),
              border: Border.all(color: AppColors.glassBorder, width: 1),
            ),
            child: child,
          ),
        ),
      ),
    );
  }
}
