import 'package:flutter/material.dart';
import '../models/news_article.dart';
import '../theme/app_theme.dart';

/// Builds the pill-shaped Material [Tab]s used in the Home screen's
/// category TabBar, styled to match the aqua theme (filled gradient pill
/// for the active tab, translucent for inactive ones is handled by the
/// surrounding TabBar's indicator — this just supplies label styling).
class CategoryTab extends StatelessWidget {
  final NewsCategory category;

  const CategoryTab({super.key, required this.category});

  @override
  Widget build(BuildContext context) {
    return Tab(
      height: 40,
      child: Text(
        category.label,
        style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
      ),
    );
  }
}

/// A ready-to-use TabBar decorated with the accent gradient indicator and
/// glass-panel background, wired to [NewsCategory.values].
class AquaCategoryTabBar extends StatelessWidget implements PreferredSizeWidget {
  final TabController controller;

  const AquaCategoryTabBar({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: AppColors.glassFill,
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: AppColors.glassBorder),
      ),
      child: TabBar(
        controller: controller,
        isScrollable: true,
        dividerColor: Colors.transparent,
        indicator: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          gradient: AppColors.accentGradient,
        ),
        tabs: NewsCategory.values.map((c) => CategoryTab(category: c)).toList(),
      ),
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(56);
}
