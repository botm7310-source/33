import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Central palette + theme for the "water/aqua" visual identity.
class AppColors {
  static const Color deepNavy = Color(0xFF0A1628);
  static const Color midBlue = Color(0xFF1A3A5C);
  static const Color cyan = Color(0xFF00D4FF);
  static const Color lightAqua = Color(0xFF4DE8E8);

  static const Color glassFill = Color(0x14FFFFFF); // rgba(255,255,255,0.08)
  static const Color glassBorder = Color(0x33FFFFFF); // rgba(255,255,255,0.2)

  static const Color textPrimary = Color(0xFFF2FBFF);
  static const Color textSecondary = Color(0xFFA9C4D6);

  /// Simulated "water depth" background: lighter near the top, darker at
  /// the bottom, used on splash/login/full-page backgrounds.
  static const LinearGradient depthGradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [midBlue, deepNavy],
  );

  static const LinearGradient accentGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [cyan, lightAqua],
  );

  /// Soft cyan glow used behind buttons / active tabs.
  static List<BoxShadow> glow({double blur = 20, double opacity = 0.35}) => [
        BoxShadow(
          color: cyan.withOpacity(opacity),
          blurRadius: blur,
          spreadRadius: 1,
        ),
      ];
}

class AppRadii {
  static const double card = 20;
  static const double button = 16;
  static const double sheet = 24;
}

class AppTheme {
  static ThemeData get dark {
    final base = ThemeData.dark(useMaterial3: true);
    final textTheme = GoogleFonts.interTextTheme(base.textTheme).apply(
      bodyColor: AppColors.textPrimary,
      displayColor: AppColors.textPrimary,
    );

    return base.copyWith(
      scaffoldBackgroundColor: AppColors.deepNavy,
      primaryColor: AppColors.cyan,
      colorScheme: base.colorScheme.copyWith(
        primary: AppColors.cyan,
        secondary: AppColors.lightAqua,
        surface: AppColors.midBlue,
        error: const Color(0xFFFF6B6B),
      ),
      textTheme: textTheme,
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        foregroundColor: AppColors.textPrimary,
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.glassFill,
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppRadii.button),
          borderSide: const BorderSide(color: AppColors.glassBorder),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppRadii.button),
          borderSide: const BorderSide(color: AppColors.glassBorder),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppRadii.button),
          borderSide: const BorderSide(color: AppColors.cyan, width: 1.5),
        ),
        hintStyle: const TextStyle(color: AppColors.textSecondary),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.cyan,
          foregroundColor: AppColors.deepNavy,
          padding: const EdgeInsets.symmetric(vertical: 16),
          textStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppRadii.button),
          ),
        ),
      ),
      tabBarTheme: const TabBarThemeData(
        labelColor: AppColors.deepNavy,
        unselectedLabelColor: AppColors.textSecondary,
        indicatorSize: TabBarIndicatorSize.tab,
      ),
    );
  }
}
