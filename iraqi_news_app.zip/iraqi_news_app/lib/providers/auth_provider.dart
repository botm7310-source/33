import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import '../services/firebase_service.dart';
import '../models/user_model.dart';

enum AuthStatus { unknown, authenticated, unauthenticated }

/// Exposes authentication state and actions to the UI via Provider.
class AuthProvider extends ChangeNotifier {
  final FirebaseService _firebaseService;

  AuthProvider({FirebaseService? firebaseService})
      : _firebaseService = firebaseService ?? FirebaseService() {
    _firebaseService.authStateChanges.listen(_onAuthChanged);
  }

  AuthStatus status = AuthStatus.unknown;
  User? _user;
  String? errorMessage;
  bool isLoading = false;

  User? get user => _user;
  UserModel? profile;

  void _onAuthChanged(User? user) {
    _user = user;
    status = user == null ? AuthStatus.unauthenticated : AuthStatus.authenticated;
    if (user != null) {
      _firebaseService.streamUser(user.uid).listen((p) {
        profile = p;
        notifyListeners();
      });
    }
    notifyListeners();
  }

  Future<bool> signIn(String email, String password) async {
    return _runAuthAction(() => _firebaseService.signIn(email, password));
  }

  Future<bool> signUp(String email, String password, String? displayName) async {
    return _runAuthAction(
      () => _firebaseService.signUp(email, password, displayName),
    );
  }

  Future<bool> _runAuthAction(Future<void> Function() action) async {
    isLoading = true;
    errorMessage = null;
    notifyListeners();
    try {
      await action();
      isLoading = false;
      notifyListeners();
      return true;
    } on FirebaseAuthException catch (e) {
      errorMessage = _friendlyMessage(e.code);
      isLoading = false;
      notifyListeners();
      return false;
    } catch (e) {
      errorMessage = 'Something went wrong. Please try again.';
      isLoading = false;
      notifyListeners();
      return false;
    }
  }

  String _friendlyMessage(String code) {
    switch (code) {
      case 'user-not-found':
        return 'No account found with that email.';
      case 'wrong-password':
      case 'invalid-credential':
        return 'Incorrect email or password.';
      case 'email-already-in-use':
        return 'An account already exists with that email.';
      case 'weak-password':
        return 'Please choose a stronger password (6+ characters).';
      case 'invalid-email':
        return 'Please enter a valid email address.';
      default:
        return 'Authentication error: $code';
    }
  }

  Future<void> signOut() => _firebaseService.signOut();
}
