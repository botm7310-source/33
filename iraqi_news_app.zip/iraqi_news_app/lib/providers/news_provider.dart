import 'dart:async';
import 'package:flutter/foundation.dart';
import '../models/news_article.dart';
import '../services/firebase_service.dart';
import '../services/news_api_service.dart';

/// Drives the Home feed: category filter, article list, loading/error
/// state, pull-to-refresh, and an in-app hourly refresh fallback.
///
/// Articles are read from Firestore (populated by the Cloud Function or by
/// `refreshFromApi`, below) so all users share one deduplicated feed rather
/// than each device hitting the news API independently.
class NewsProvider extends ChangeNotifier {
  final FirebaseService _firebaseService;
  final NewsApiService _newsApiService;

  NewsProvider({
    FirebaseService? firebaseService,
    NewsApiService? newsApiService,
  })  : _firebaseService = firebaseService ?? FirebaseService(),
        _newsApiService = newsApiService ?? NewsApiService() {
    _listenToCategory(NewsCategory.all);
    _startHourlyFallbackTimer();
  }

  NewsCategory selectedCategory = NewsCategory.all;
  List<NewsArticle> articles = [];
  bool isLoading = true;
  bool isRefreshing = false;
  String? errorMessage;

  StreamSubscription<List<NewsArticle>>? _sub;
  Timer? _hourlyTimer;

  void selectCategory(NewsCategory category) {
    if (category == selectedCategory) return;
    selectedCategory = category;
    isLoading = true;
    notifyListeners();
    _listenToCategory(category);
  }

  void _listenToCategory(NewsCategory category) {
    _sub?.cancel();
    _sub = _firebaseService.streamArticles(category: category).listen(
      (data) {
        articles = data;
        isLoading = false;
        errorMessage = null;
        notifyListeners();
      },
      onError: (e) {
        isLoading = false;
        errorMessage = 'Could not load articles: $e';
        notifyListeners();
      },
    );
  }

  /// Pull-to-refresh handler: fetches fresh articles directly from the API
  /// and writes any new ones into Firestore. The Firestore listener above
  /// then updates the UI automatically once the write completes.
  ///
  /// Note: in production, prefer letting the Cloud Function (functions/
  /// index.js) own ingestion, and have this just trigger it or simply
  /// re-read Firestore — that avoids every user's pull-to-refresh
  /// consuming API quota and avoids write races. This client-side path is
  /// provided as a working fallback / for local development.
  Future<void> refreshFromApi() async {
    isRefreshing = true;
    notifyListeners();
    try {
      final fetched = await _newsApiService.fetchIraqNewsToday();
      await _firebaseService.saveArticlesDeduped(fetched);
    } on NewsApiException catch (e) {
      errorMessage = e.message;
    } catch (e) {
      errorMessage = 'Refresh failed: $e';
    } finally {
      isRefreshing = false;
      notifyListeners();
    }
  }

  void _startHourlyFallbackTimer() {
    _hourlyTimer = Timer.periodic(const Duration(hours: 1), (_) {
      refreshFromApi();
    });
  }

  Future<void> toggleSaved(String uid, NewsArticle article, bool save) {
    if (article.id == null) return Future.value();
    return _firebaseService.toggleSaved(uid, article.id!, save);
  }

  @override
  void dispose() {
    _sub?.cancel();
    _hourlyTimer?.cancel();
    _newsApiService.dispose();
    super.dispose();
  }
}
