import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/news_article.dart';
import '../providers/auth_provider.dart';
import '../providers/news_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/category_tab.dart';
import '../widgets/news_card.dart';
import 'article_detail_screen.dart';
import 'profile_screen.dart';

/// Home Feed: category TabBar + a wave-animated list of [NewsCard]s with
/// pull-to-refresh. Backed by [NewsProvider], which streams from Firestore.
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(
      length: NewsCategory.values.length,
      vsync: this,
    );
    _tabController.addListener(() {
      if (!_tabController.indexIsChanging) {
        context
            .read<NewsProvider>()
            .selectCategory(NewsCategory.values[_tabController.index]);
      }
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final news = context.watch<NewsProvider>();
    final auth = context.watch<AuthProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Iraqi Daily News'),
        actions: [
          IconButton(
            icon: const Icon(Icons.person_outline),
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const ProfileScreen()),
            ),
          ),
        ],
        bottom: AquaCategoryTabBar(controller: _tabController),
      ),
      body: Container(
        decoration: const BoxDecoration(gradient: AppColors.depthGradient),
        child: RefreshIndicator(
          color: AppColors.cyan,
          backgroundColor: AppColors.midBlue,
          onRefresh: news.refreshFromApi,
          child: _buildBody(news, auth),
        ),
      ),
    );
  }

  Widget _buildBody(NewsProvider news, AuthProvider auth) {
    if (news.isLoading) {
      return const Center(
        child: CircularProgressIndicator(color: AppColors.cyan),
      );
    }

    if (news.errorMessage != null && news.articles.isEmpty) {
      return _errorState(news.errorMessage!, news.refreshFromApi);
    }

    if (news.articles.isEmpty) {
      return _emptyState(news.refreshFromApi);
    }

    final savedIds = auth.profile?.savedArticleIds ?? const [];

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      physics: const AlwaysScrollableScrollPhysics(),
      itemCount: news.articles.length,
      itemBuilder: (context, index) {
        final article = news.articles[index];
        return TweenAnimationBuilder<double>(
          // A subtle "wave" staggered entrance: each card fades/slides in
          // slightly later than the one above it.
          tween: Tween(begin: 0, end: 1),
          duration: Duration(milliseconds: 300 + (index * 40).clamp(0, 400)),
          curve: Curves.easeOutCubic,
          builder: (context, value, child) => Opacity(
            opacity: value,
            child: Transform.translate(
              offset: Offset(0, (1 - value) * 24),
              child: child,
            ),
          ),
          child: NewsCard(
            article: article,
            isSaved: article.id != null && savedIds.contains(article.id),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => ArticleDetailScreen(article: article),
              ),
            ),
            onSaveToggle: auth.user == null
                ? null
                : () => news.toggleSaved(
                      auth.user!.uid,
                      article,
                      !(article.id != null && savedIds.contains(article.id)),
                    ),
          ),
        );
      },
    );
  }

  Widget _emptyState(Future<void> Function() onRetry) {
    return LayoutBuilder(
      builder: (context, constraints) => SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        child: SizedBox(
          height: constraints.maxHeight,
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.water_drop_outlined,
                    size: 48, color: AppColors.lightAqua),
                const SizedBox(height: 12),
                const Text('No articles yet',
                    style: TextStyle(color: AppColors.textPrimary)),
                const SizedBox(height: 6),
                const Text('Pull down to fetch the latest news',
                    style: TextStyle(color: AppColors.textSecondary)),
                const SizedBox(height: 16),
                TextButton(onPressed: onRetry, child: const Text('Refresh now')),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _errorState(String message, Future<void> Function() onRetry) {
    return LayoutBuilder(
      builder: (context, constraints) => SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        child: SizedBox(
          height: constraints.maxHeight,
          child: Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 32),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.error_outline,
                      size: 48, color: Color(0xFFFF8A8A)),
                  const SizedBox(height: 12),
                  Text(message,
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: AppColors.textPrimary)),
                  const SizedBox(height: 16),
                  ElevatedButton(onPressed: onRetry, child: const Text('Try again')),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
