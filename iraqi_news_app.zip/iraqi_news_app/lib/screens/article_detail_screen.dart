import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'package:url_launcher/url_launcher.dart';
import '../models/news_article.dart';
import '../providers/auth_provider.dart';
import '../providers/news_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/glass_container.dart';

/// Full article view: hero image, full text (falling back to the summary
/// if the API didn't return `full_text`), source attribution with an
/// "open original" link, share, and save-to-favorites.
class ArticleDetailScreen extends StatelessWidget {
  final NewsArticle article;

  const ArticleDetailScreen({super.key, required this.article});

  Future<void> _openSource() async {
    final uri = Uri.tryParse(article.sourceUrl);
    if (uri != null) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  void _share() {
    SharePlus.instance.share(
      ShareParams(
        text: '${article.title}\n\n${article.sourceUrl}',
        subject: article.title,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final news = context.read<NewsProvider>();
    final savedIds = auth.profile?.savedArticleIds ?? const [];
    final isSaved = article.id != null && savedIds.contains(article.id);

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: AppColors.depthGradient),
        child: CustomScrollView(
          slivers: [
            SliverAppBar(
              pinned: true,
              expandedHeight: article.imageUrl != null ? 240 : 100,
              backgroundColor: AppColors.deepNavy,
              flexibleSpace: FlexibleSpaceBar(
                background: article.imageUrl != null
                    ? CachedNetworkImage(
                        imageUrl: article.imageUrl!,
                        fit: BoxFit.cover,
                        errorWidget: (_, __, ___) =>
                            Container(color: AppColors.midBlue),
                      )
                    : Container(color: AppColors.midBlue),
              ),
              actions: [
                IconButton(
                  icon: const Icon(Icons.share_outlined),
                  onPressed: _share,
                ),
                if (auth.user != null)
                  IconButton(
                    icon: Icon(
                      isSaved ? Icons.bookmark : Icons.bookmark_border,
                      color: AppColors.cyan,
                    ),
                    onPressed: () =>
                        news.toggleSaved(auth.user!.uid, article, !isSaved),
                  ),
              ],
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Wrap(
                      spacing: 8,
                      children: [
                        Chip(
                          label: Text(article.category.label),
                          backgroundColor: AppColors.glassFill,
                          side: const BorderSide(color: AppColors.glassBorder),
                          labelStyle: const TextStyle(color: AppColors.lightAqua),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Text(
                      article.title,
                      style: const TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w800,
                        color: AppColors.textPrimary,
                        height: 1.3,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      '${article.sourceName} · ${timeago.format(article.publishedAt)}',
                      style: const TextStyle(
                        color: AppColors.textSecondary,
                        fontSize: 13,
                      ),
                    ),
                    const SizedBox(height: 20),
                    GlassContainer(
                      child: Text(
                        (article.fullText?.trim().isNotEmpty ?? false)
                            ? article.fullText!
                            : article.summary,
                        style: const TextStyle(
                          color: AppColors.textPrimary,
                          fontSize: 15,
                          height: 1.6,
                        ),
                      ),
                    ),
                    const SizedBox(height: 24),
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton.icon(
                        onPressed: _openSource,
                        icon: const Icon(Icons.open_in_new,
                            color: AppColors.cyan),
                        label: const Text('Read original source'),
                        style: OutlinedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          side: const BorderSide(color: AppColors.cyan),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(AppRadii.button),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
