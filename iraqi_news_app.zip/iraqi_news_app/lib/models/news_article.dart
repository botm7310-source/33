import 'package:cloud_firestore/cloud_firestore.dart';

/// Supported editorial categories shown as tabs on the Home screen.
enum NewsCategory { all, politics, economy, security, kurdistan, world }

extension NewsCategoryX on NewsCategory {
  String get label {
    switch (this) {
      case NewsCategory.all:
        return 'All';
      case NewsCategory.politics:
        return 'Politics';
      case NewsCategory.economy:
        return 'Economy';
      case NewsCategory.security:
        return 'Security';
      case NewsCategory.kurdistan:
        return 'Kurdistan';
      case NewsCategory.world:
        return 'World';
    }
  }

  static NewsCategory fromString(String? raw) {
    switch ((raw ?? '').toLowerCase().trim()) {
      case 'politics':
        return NewsCategory.politics;
      case 'economy':
      case 'business':
        return NewsCategory.economy;
      case 'security':
        return NewsCategory.security;
      case 'kurdistan':
      case 'kurdistan region':
      case 'kurdish':
        return NewsCategory.kurdistan;
      case 'world':
      case 'international':
        return NewsCategory.world;
      default:
        return NewsCategory.all;
    }
  }
}

/// Core article model used across the app (API layer, Firestore layer, UI layer).
class NewsArticle {
  final String? id; // Firestore document id (null until persisted)
  final String title;
  final String summary;
  final String? imageUrl;
  final String sourceUrl;
  final String sourceName;
  final NewsCategory category;
  final DateTime publishedAt;
  final DateTime? fetchedAt;
  final String? fullText;

  const NewsArticle({
    this.id,
    required this.title,
    required this.summary,
    this.imageUrl,
    required this.sourceUrl,
    required this.sourceName,
    this.category = NewsCategory.all,
    required this.publishedAt,
    this.fetchedAt,
    this.fullText,
  });

  /// Builds an article from a FreeNewsApi-style JSON search result.
  ///
  /// The parser is defensive: FreeNewsApi-style endpoints commonly vary
  /// field names between `headline`/`title`, `description`/`summary`, etc.,
  /// so we check several likely keys before giving up on a field.
  factory NewsArticle.fromApiJson(Map<String, dynamic> json) {
    final title = (json['headline'] ?? json['title'] ?? '').toString().trim();
    final description =
        (json['description'] ?? json['summary'] ?? json['snippet'] ?? '')
            .toString()
            .trim();
    final url = (json['url'] ?? json['original_url'] ?? json['link'] ?? '')
        .toString()
        .trim();
    final publisher =
        (json['publisher'] ?? json['source'] ?? json['sourceName'] ?? 'Unknown')
            .toString()
            .trim();
    final image = (json['image'] ??
            json['image_url'] ??
            json['imageUrl'] ??
            json['thumbnail'])
        ?.toString();

    DateTime published;
    final rawDate = json['published_at'] ??
        json['publication_time'] ??
        json['publishedAt'] ??
        json['date'];
    try {
      published = rawDate != null
          ? DateTime.parse(rawDate.toString())
          : DateTime.now();
    } catch (_) {
      published = DateTime.now();
    }

    return NewsArticle(
      title: title.isEmpty ? 'Untitled' : title,
      summary: description,
      imageUrl: (image == null || image.isEmpty) ? null : image,
      sourceUrl: url,
      sourceName: publisher.isEmpty ? 'Unknown' : publisher,
      category: NewsCategoryX.fromString(json['category']?.toString()),
      publishedAt: published,
      fullText: json['full_text']?.toString(),
    );
  }

  /// Builds an article from a Firestore document snapshot.
  factory NewsArticle.fromFirestore(DocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data() ?? {};
    return NewsArticle(
      id: doc.id,
      title: data['title'] ?? '',
      summary: data['summary'] ?? '',
      imageUrl: data['imageUrl'],
      sourceUrl: data['sourceUrl'] ?? '',
      sourceName: data['sourceName'] ?? 'Unknown',
      category: NewsCategoryX.fromString(data['category']),
      publishedAt: (data['publishedAt'] is Timestamp)
          ? (data['publishedAt'] as Timestamp).toDate()
          : DateTime.tryParse(data['publishedAt']?.toString() ?? '') ??
              DateTime.now(),
      fetchedAt: data['fetchedAt'] is Timestamp
          ? (data['fetchedAt'] as Timestamp).toDate()
          : null,
      fullText: data['fullText'],
    );
  }

  /// Converts the article to a Firestore-writable map.
  /// `fetchedAt` uses the server timestamp sentinel so all clients agree on
  /// ingestion time regardless of local clock skew.
  Map<String, dynamic> toFirestore() {
    return {
      'title': title,
      'summary': summary,
      'imageUrl': imageUrl,
      'sourceUrl': sourceUrl,
      'sourceName': sourceName,
      'category': category.name,
      'publishedAt': Timestamp.fromDate(publishedAt),
      'fetchedAt': FieldValue.serverTimestamp(),
      if (fullText != null) 'fullText': fullText,
    };
  }
}
