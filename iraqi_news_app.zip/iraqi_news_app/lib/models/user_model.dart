import 'package:cloud_firestore/cloud_firestore.dart';

/// Represents an application user, mirrored into the `users` Firestore
/// collection alongside Firebase Auth.
class UserModel {
  final String uid;
  final String email;
  final String? displayName;
  final DateTime? createdAt;
  final List<String> savedArticleIds;

  const UserModel({
    required this.uid,
    required this.email,
    this.displayName,
    this.createdAt,
    this.savedArticleIds = const [],
  });

  factory UserModel.fromFirestore(DocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data() ?? {};
    return UserModel(
      uid: doc.id,
      email: data['email'] ?? '',
      displayName: data['displayName'],
      createdAt: (data['createdAt'] is Timestamp)
          ? (data['createdAt'] as Timestamp).toDate()
          : null,
      savedArticleIds: List<String>.from(data['savedArticleIds'] ?? const []),
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'uid': uid,
      'email': email,
      'displayName': displayName,
      'createdAt': FieldValue.serverTimestamp(),
      'savedArticleIds': savedArticleIds,
    };
  }
}
