# Iraqi Daily News

A cross-platform Flutter news app delivering Iraqi daily news, with an aqua/water-themed UI, Firebase Auth + Firestore backend, and an hourly ingestion pipeline.

> ⚠️ **Before you deploy: verify the news data source.**
> This project was specified to use `https://freenewsapi.ai/v1/search`. That domain could not be independently confirmed as a live, documented API while this project was built. Test it yourself first:
> ```bash
> curl "https://freenewsapi.ai/v1/search?country=IQ&date=today&sort=date&size=5"
> ```
> - If it returns JSON matching what you expect, you're good — the app is already wired to it in two places: `lib/services/news_api_service.dart` (client fallback) and `functions/index.js` (hourly server job).
> - If it 404s, doesn't exist, or the shape differs, swap in a verified provider (e.g. GDELT Project's free API, NewsData.io, NewsAPI.ai with a free key, or your own scraper). You only need to change `NEWS_API_BASE_URL`/`_baseUrl` and the field-mapping logic in those two files — the rest of the app depends only on the `NewsArticle` model, not on the specific API.

## Tech stack
- Flutter 3.0+, Dart, Provider for state management
- Firebase Authentication (email/password) + Cloud Firestore
- Cloud Functions (Node 20) for scheduled hourly ingestion
- Aqua/glassmorphism UI theme (see `lib/theme/app_theme.dart`)

## Project structure
```
lib/
  main.dart
  models/           news_article.dart, user_model.dart
  providers/        auth_provider.dart, news_provider.dart
  services/         news_api_service.dart, firebase_service.dart
  screens/          splash, login, home, article_detail, profile
  widgets/          news_card, category_tab, glass_container
  theme/            app_theme.dart
functions/
  index.js          hourly scheduled fetch + dedupe + manual trigger
firestore.rules
```

## 1. Prerequisites
- Flutter SDK 3.0+ (`flutter --version`)
- A Firebase project (create one at https://console.firebase.google.com)
- Node.js 20+ and the Firebase CLI: `npm install -g firebase-tools`
- FlutterFire CLI: `dart pub global activate flutterfire_cli`

## 2. Firebase setup

1. **Create the Firebase project** in the console (or `firebase projects:create`).
2. **Enable Authentication** → Sign-in method → enable **Email/Password**.
3. **Enable Firestore** → create database → start in production mode (rules are provided in `firestore.rules`).
4. **Connect your Flutter app to Firebase:**
   ```bash
   cd iraqi_news_app
   firebase login
   flutterfire configure
   ```
   This generates `lib/firebase_options.dart` (imported by `main.dart`) and registers your Android/iOS/web app IDs. Select the platforms you're targeting when prompted.
5. **Deploy Firestore rules:**
   ```bash
   firebase deploy --only firestore:rules
   ```
6. **(Recommended) Create a composite index** for category-filtered feed queries: Firestore will prompt you with a direct console link the first time you run a `where(category) + orderBy(publishedAt)` query in the app — click it to auto-create the index, or add it manually in Firestore → Indexes.

## 3. Install Flutter dependencies
```bash
flutter pub get
```

## 4. Cloud Functions (hourly ingestion)
```bash
cd functions
npm install
cd ..
firebase deploy --only functions
```
This deploys:
- `fetchIraqNewsHourly` — scheduled function, runs every hour, fetches + dedupes + writes new articles.
- `fetchIraqNewsNow` — HTTPS endpoint for manually triggering an ingest run (useful for testing; add an App Check or shared-secret guard before using in production).

You can test ingestion locally first with the emulator:
```bash
cd functions
npm run serve
```

## 5. Run the app
```bash
flutter run
```

## 6. Build for release
```bash
# Android
flutter build appbundle --release

# iOS (on macOS, with Xcode + signing configured)
flutter build ipa --release
```

## How data flows
1. `functions/index.js`'s `fetchIraqNewsHourly` runs every hour, calls the news API, skips any article whose `sourceUrl` already exists in `articles`, and writes the rest with `fetchedAt: serverTimestamp()`.
2. The app's `NewsProvider` subscribes to `articles` via a live Firestore `snapshots()` stream (see `FirebaseService.streamArticles`) — so once the function writes new articles, every open app instance updates automatically, no polling needed.
3. Pull-to-refresh on the Home screen (`NewsProvider.refreshFromApi`) is a **client-side fallback** that also fetches + dedupes + writes, useful during development or if you haven't deployed Cloud Functions yet. In production, prefer disabling this and relying solely on the scheduled function, to avoid every user's device consuming API quota and to avoid write races.

## Known gaps / things to finish before shipping
- `assets/fonts/Inter-*.ttf` and `assets/images/`, `assets/icons/` referenced in `pubspec.yaml` are not included — either add real asset files or remove those blocks.
- No password-reset flow yet (add `FirebaseAuth.sendPasswordResetEmail` + a screen if needed).
- The `fetchIraqNewsNow` HTTPS function has no auth guard — lock it down before deploying publicly.
- `category` values from the news API are guessed via keyword matching in `NewsCategoryX.fromString` — if the real API returns different category labels/taxonomy, adjust that mapping.
