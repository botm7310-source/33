/**
 * Cloud Functions for the Iraqi Daily News app.
 *
 * `fetchIraqNewsHourly` runs every hour, pulls today's Iraq news from the
 * configured news API, deduplicates against Firestore by `sourceUrl`, and
 * writes new articles into the `articles` collection with a server
 * timestamp. Running this server-side (rather than from each client) is
 * what keeps the feed identical for every user and avoids every device
 * spending API/Firestore quota on ingestion.
 *
 * IMPORTANT: The NEWS_API_BASE_URL below was supplied by the project spec
 * as "freenewsapi.ai" but could not be verified as a live, documented
 * service. Confirm it works (or swap in a verified provider) before
 * deploying to production — this file only needs the base URL and the
 * `normalizeArticle` mapping changed if you switch providers.
 */

const { onSchedule } = require('firebase-functions/v2/scheduler');
const { onRequest } = require('firebase-functions/v2/https');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore, FieldValue, Timestamp } = require('firebase-admin/firestore');

initializeApp();
const db = getFirestore();

const NEWS_API_BASE_URL = 'https://freenewsapi.ai/v1/search';

/** Maps a raw API item into the Firestore `articles` document shape. */
function normalizeArticle(raw) {
  const title = (raw.headline || raw.title || '').toString().trim();
  const sourceUrl = (raw.url || raw.original_url || raw.link || '').toString().trim();
  if (!title || !sourceUrl) return null; // essentials missing — skip

  const publishedRaw =
    raw.published_at || raw.publication_time || raw.publishedAt || raw.date;
  let publishedAt;
  try {
    publishedAt = publishedRaw ? new Date(publishedRaw) : new Date();
    if (isNaN(publishedAt.getTime())) publishedAt = new Date();
  } catch (_) {
    publishedAt = new Date();
  }

  return {
    title,
    summary: (raw.description || raw.summary || raw.snippet || '').toString().trim(),
    imageUrl: raw.image || raw.image_url || raw.imageUrl || raw.thumbnail || null,
    sourceUrl,
    sourceName: (raw.publisher || raw.source || 'Unknown').toString().trim(),
    category: (raw.category || 'all').toString().toLowerCase(),
    publishedAt: Timestamp.fromDate(publishedAt),
    fetchedAt: FieldValue.serverTimestamp(),
  };
}

/** Fetches, deduplicates, and writes new articles. Returns a summary. */
async function ingestArticles() {
  const url = new URL(NEWS_API_BASE_URL);
  url.searchParams.set('country', 'IQ');
  url.searchParams.set('date', 'today');
  url.searchParams.set('sort', 'date');
  url.searchParams.set('size', '50');

  const response = await fetch(url.toString(), { signal: AbortSignal.timeout(15000) });
  if (!response.ok) {
    throw new Error(`News API returned status ${response.status}`);
  }

  const body = await response.json();
  const rawList = Array.isArray(body) ? body : body.articles || body.results || body.data || [];

  const articlesRef = db.collection('articles');
  let inserted = 0;
  let skippedDuplicate = 0;
  let skippedInvalid = 0;

  for (const raw of rawList) {
    const article = normalizeArticle(raw);
    if (!article) {
      skippedInvalid++;
      continue;
    }

    // Dedup by sourceUrl.
    const existing = await articlesRef
      .where('sourceUrl', '==', article.sourceUrl)
      .limit(1)
      .get();

    if (!existing.empty) {
      skippedDuplicate++;
      continue;
    }

    await articlesRef.add(article);
    inserted++;
  }

  return { fetched: rawList.length, inserted, skippedDuplicate, skippedInvalid };
}

// Runs every hour, on the hour.
exports.fetchIraqNewsHourly = onSchedule('every 1 hours', async () => {
  try {
    const summary = await ingestArticles();
    console.log('Hourly ingest complete:', summary);
  } catch (err) {
    console.error('Hourly ingest failed:', err);
    throw err; // lets Cloud Functions record/retry the failure
  }
});

// Optional HTTPS endpoint to trigger ingestion manually (e.g. for testing,
// or to wire a client "force refresh" button without giving the client
// direct write-dedup responsibility). Protect this in production — e.g.
// require an App Check token or a shared secret header — before deploying.
exports.fetchIraqNewsNow = onRequest(async (req, res) => {
  try {
    const summary = await ingestArticles();
    res.status(200).json({ ok: true, ...summary });
  } catch (err) {
    console.error('Manual ingest failed:', err);
    res.status(500).json({ ok: false, error: err.message });
  }
});
